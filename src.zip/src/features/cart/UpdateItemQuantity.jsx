function UpdateItemQuantity({ currentQuantity }) {
  return (
    <div>
      <button>-</button>
      <span>{currentQuantity}</span>
      <button>+</button>
    </div>
  );
}

export default UpdateItemQuantity;
